import { Account, Signal } from "@/types/daily-focus";

export const mockAccounts: Account[] = [
  {
    id: "acc1",
    name: "Tech Innovations Inc.",
    logoUrl: "https://via.placeholder.com/40/0000FF/FFFFFF?text=TI",
    size: "1,000-5,000 employees",
    industry: "Software Development",
    momentum: 15,
    momentumDirection: "up",
    whatChanged: "2 new stakeholders hired this week, including a new VP of Engineering.",
    recommendedAction: "Message",
    stakeholders: [
      { id: "s1", name: "Alice Johnson", title: "VP of Engineering", avatarUrl: "https://via.placeholder.com/40/FF0000/FFFFFF?text=AJ" },
      { id: "s2", name: "Bob Williams", title: "Head of Product", avatarUrl: "https://via.placeholder.com/40/00FF00/FFFFFF?text=BW" },
    ],
    recentActivity: [
      { id: "a1", type: "Post engagement", description: "CEO commented on an industry report.", timestamp: "2024-07-25T10:00:00Z" },
      { id: "a2", type: "Company page visit", description: "Multiple employees viewed our solutions page.", timestamp: "2024-07-24T14:30:00Z" },
    ],
    riskOpportunitySignals: ["Increased hiring in AI department", "Competitor announced new partnership"],
    isPeaking: true, // Example of a "Peaking" account
  },
  {
    id: "acc2",
    name: "Global Solutions Ltd.",
    logoUrl: "https://via.placeholder.com/40/FFFF00/000000?text=GS",
    size: "500-1,000 employees",
    industry: "Consulting",
    momentum: -8,
    momentumDirection: "down",
    whatChanged: "Key decision-maker, Sarah Davis, left the company last week.",
    recommendedAction: "Save lead",
    stakeholders: [
      { id: "s3", name: "John Doe", title: "Director of Sales", avatarUrl: "https://via.placeholder.com/40/000000/FFFFFF?text=JD" },
    ],
    recentActivity: [
      { id: "a3", type: "Job change", description: "Sarah Davis, former Head of Strategy, updated her profile.", timestamp: "2024-07-23T09:00:00Z" },
    ],
    riskOpportunitySignals: ["Budget cuts reported in industry news"],
  },
  {
    id: "acc3",
    name: "Innovate Marketing",
    logoUrl: "https://via.placeholder.com/40/FF00FF/FFFFFF?text=IM",
    size: "50-200 employees",
    industry: "Marketing & Advertising",
    momentum: 5,
    momentumDirection: "up",
    whatChanged: "Company announced new product launch, indicating growth.",
    recommendedAction: "View account",
    stakeholders: [
      { id: "s4", name: "Emily White", title: "Marketing Manager", avatarUrl: "https://via.placeholder.com/40/00FFFF/000000?text=EW" },
    ],
    recentActivity: [
      { id: "a4", type: "Company news", description: "Press release about new product.", timestamp: "2024-07-26T11:00:00Z" },
    ],
    riskOpportunitySignals: ["Expanding into new markets"],
  },
  {
    id: "acc4",
    name: "Future Systems Co.",
    logoUrl: "https://via.placeholder.com/40/800080/FFFFFF?text=FS",
    size: "200-500 employees",
    industry: "IT Services",
    momentum: 0,
    momentumDirection: "neutral",
    whatChanged: "No significant changes detected, consistent engagement.",
    recommendedAction: "Message",
    stakeholders: [
      { id: "s5", name: "David Green", title: "IT Director", avatarUrl: "https://via.placeholder.com/40/FFA500/FFFFFF?text=DG" },
    ],
    recentActivity: [
      { id: "a5", type: "Website visit", description: "Visited pricing page twice this week.", timestamp: "2024-07-25T16:00:00Z" },
    ],
    riskOpportunitySignals: ["Upcoming contract renewal"],
  },
];

export const mockSignals: Signal[] = [
  { id: "sig1", type: "Job Change", description: "Sarah Davis moved to a new role at", accountName: "New Horizons Corp.", timestamp: "2024-07-26T15:00:00Z" },
  { id: "sig2", type: "Engagement Spike", description: "Tech Innovations Inc. employees showed high engagement with our recent post on AI trends.", timestamp: "2024-07-26T14:00:00Z" },
  { id: "sig3", type: "Hiring Trend", description: "Global Solutions Ltd. is hiring aggressively for cloud architects.", timestamp: "2024-07-26T12:00:00Z" },
  { id: "sig4", type: "Company News", description: "Innovate Marketing announced a new partnership with a major influencer.", timestamp: "2024-07-25T18:00:00Z" },
  { id: "sig5", type: "Lead Activity", description: "New lead, Michael Brown, from Future Systems Co. viewed our product demo.", leadName: "Michael Brown", timestamp: "2024-07-25T11:00:00Z" },
];