"use client";

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { formatDistanceToNowStrict } from "date-fns";
import { Signal } from "@/types/daily-focus";

interface SignalCardProps {
  signal: Signal;
}

const SignalCard: React.FC<SignalCardProps> = ({ signal }) => {
  const timeAgo = formatDistanceToNowStrict(new Date(signal.timestamp), { addSuffix: true });

  return (
    <Card className="border-gray-200 dark:border-gray-700 hover:shadow-sm transition-shadow duration-200">
      <CardContent className="p-3 text-sm">
        <div className="flex justify-between items-center mb-1">
          <span className="font-medium text-gray-800 dark:text-gray-200">{signal.type}</span>
          <span className="text-gray-500 dark:text-gray-400 text-xs">{timeAgo}</span>
        </div>
        <p className="text-gray-700 dark:text-gray-300 leading-snug">
          {signal.description}
          {signal.accountName && (
            <span className="font-semibold text-blue-600 dark:text-blue-400 ml-1">{signal.accountName}</span>
          )}
          {signal.leadName && (
            <span className="font-semibold text-blue-600 dark:text-blue-400 ml-1">{signal.leadName}</span>
          )}
        </p>
      </CardContent>
    </Card>
  );
};

export default SignalCard;