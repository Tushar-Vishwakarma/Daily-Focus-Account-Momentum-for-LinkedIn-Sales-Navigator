"use client";

import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Lightbulb, MessageSquare, Save, Eye, ArrowLeft } from "lucide-react"; // Import ArrowLeft icon
import { Account, Stakeholder, Activity } from "@/types/daily-focus";
import { format } from "date-fns";

interface AccountDetailPreviewProps {
  account: Account | null;
  onBack: () => void; // New prop to handle going back to the list
}

const AccountDetailPreview: React.FC<AccountDetailPreviewProps> = ({ account, onBack }) => {
  if (!account) {
    return (
      <div className="h-full flex items-center justify-center bg-white dark:bg-gray-950">
        <p className="text-gray-500 dark:text-gray-400">Select an account from the Focus Queue to see details.</p>
      </div>
    );
  }

  const actionIcon =
    account.recommendedAction === "Message" ? (
      <MessageSquare className="h-4 w-4 mr-2" />
    ) : account.recommendedAction === "Save lead" ? (
      <Save className="h-4 w-4 mr-2" />
    ) : (
      <Eye className="h-4 w-4 mr-2" />
    );

  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-950">
      <CardHeader className="p-4 border-b border-gray-200 dark:border-gray-800 flex flex-row items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="icon" onClick={onBack} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Avatar className="h-10 w-10">
            <AvatarImage src={account.logoUrl} alt={account.name} />
            <AvatarFallback>{account.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-xl font-bold">{account.name}</CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {account.size} • {account.industry}
            </p>
          </div>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-500 dark:hover:bg-blue-600">
          {actionIcon}
          {account.recommendedAction}
        </Button>
      </CardHeader>
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-6">
          {/* Why this account matters today */}
          <div>
            <h3 className="text-md font-semibold mb-2 text-blue-700 dark:text-blue-400 flex items-center">
              <Lightbulb className="h-5 w-5 mr-2 text-yellow-500" />
              Why this account matters today
            </h3>
            <p className="text-gray-800 dark:text-gray-200">{account.whatChanged}</p>
          </div>

          <Separator className="bg-gray-200 dark:bg-gray-700" />

          {/* Key Stakeholders */}
          <div>
            <h3 className="text-md font-semibold mb-3">Key Stakeholders ({account.stakeholders.length})</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {account.stakeholders.map((stakeholder: Stakeholder) => (
                <div key={stakeholder.id} className="flex items-center space-x-3">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={stakeholder.avatarUrl} alt={stakeholder.name} />
                    <AvatarFallback>{stakeholder.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-200">{stakeholder.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{stakeholder.title}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator className="bg-gray-200 dark:bg-gray-700" />

          {/* Recent Activity */}
          <div>
            <h3 className="text-md font-semibold mb-3">Recent Activity ({account.recentActivity.length})</h3>
            <div className="space-y-3">
              {account.recentActivity.map((activity: Activity) => (
                <div key={activity.id} className="text-sm">
                  <p className="font-medium text-gray-800 dark:text-gray-200">{activity.type}</p>
                  <p className="text-gray-700 dark:text-gray-300">{activity.description}</p>
                  <p className="text-gray-500 dark:text-gray-400 text-xs">
                    {format(new Date(activity.timestamp), "MMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <Separator className="bg-gray-200 dark:bg-gray-700" />

          {/* Risk/Opportunity Signals */}
          <div>
            <h3 className="text-md font-semibold mb-3">Risk/Opportunity Signals</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-800 dark:text-gray-200">
              {account.riskOpportunitySignals.map((signal, index) => (
                <li key={index}>{signal}</li>
              ))}
            </ul>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

export default AccountDetailPreview;