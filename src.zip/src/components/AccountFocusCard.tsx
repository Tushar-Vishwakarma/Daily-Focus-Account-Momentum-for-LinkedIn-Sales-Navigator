"use client";

import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowUp, ArrowDown, MessageSquare, Save, Eye } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Account } from "@/types/daily-focus";
import { cn } from "@/lib/utils";

interface AccountFocusCardProps {
  account: Account;
  isSelected: boolean;
  onSelect: (accountId: string) => void;
}

const AccountFocusCard: React.FC<AccountFocusCardProps> = ({ account, isSelected, onSelect }) => {
  const momentumIcon =
    account.momentumDirection === "up" ? (
      <ArrowUp className="h-4 w-4 text-green-500" />
    ) : account.momentumDirection === "down" ? (
      <ArrowDown className="h-4 w-4 text-red-500" />
    ) : null;

  const momentumColor =
    account.momentumDirection === "up"
      ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      : account.momentumDirection === "down"
      ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";

  const actionIcon =
    account.recommendedAction === "Message" ? (
      <MessageSquare className="h-4 w-4 mr-2" />
    ) : account.recommendedAction === "Save lead" ? (
      <Save className="h-4 w-4 mr-2" />
    ) : (
      <Eye className="h-4 w-4 mr-2" />
    );

  const isHighMomentum = account.momentumDirection === "up" && account.momentum >= 10;
  const isPeaking = account.isPeaking; // Use the new property

  return (
    <Card
      className={cn(
        "cursor-pointer hover:shadow-md transition-all duration-200",
        isSelected ? "border-blue-500 ring-2 ring-blue-200 dark:ring-blue-700" : "border-gray-200 dark:border-gray-700"
      )}
      onClick={() => onSelect(account.id)}
    >
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center space-x-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={account.logoUrl} alt={account.name} />
            <AvatarFallback>{account.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <CardTitle className="text-base font-semibold">{account.name}</CardTitle>
        </div>
        <div className="flex items-center gap-2"> {/* Grouping badges */}
          {isHighMomentum && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
              High Momentum
            </Badge>
          )}
          {isPeaking && (
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
              Peaking
            </Badge>
          )}
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge className={cn("flex items-center gap-1", momentumColor)}>
                {momentumIcon}
                <span>{account.momentum}%</span>
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Momentum change over the last 7 days</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </CardHeader>
      <CardContent className="space-y-2 text-sm">
        <p className="text-gray-600 dark:text-gray-400">
          {account.size} • {account.industry}
        </p>
        <p className="text-gray-800 dark:text-gray-200 font-medium">
          {account.whatChanged}
        </p>
        <Button variant="outline" size="sm" className="w-full mt-2 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-700 hover:bg-blue-50 dark:hover:bg-blue-900">
          {actionIcon}
          {account.recommendedAction}
        </Button>
      </CardContent>
    </Card>
  );
};

export default AccountFocusCard;