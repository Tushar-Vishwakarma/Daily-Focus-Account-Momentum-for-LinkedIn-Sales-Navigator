"use client";

import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input"; // Import Input component
import SignalCard from "./SignalCard";
import { Signal } from "@/types/daily-focus";
import { showSuccess } from "@/utils/toast"; // Import showSuccess

interface SignalsFeedProps {
  signals: Signal[];
  searchTerm: string; // New prop for search term
  onSearchChange: (term: string) => void; // New prop for search handler
}

const SignalsFeed: React.FC<SignalsFeedProps> = ({ signals, searchTerm, onSearchChange }) => {
  const handleViewAllClick = () => {
    showSuccess("Viewing all signals (feature coming soon!)");
    // In a real application, this would navigate to a dedicated 'All Signals' page or open a modal.
  };

  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-950 border-l border-gray-200 dark:border-gray-800">
      <div className="flex flex-col p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold">Signals & Changes Feed</h2>
          <Button variant="link" size="sm" className="text-blue-600 dark:text-blue-400" onClick={handleViewAllClick}>
            View All
          </Button>
        </div>
        <Input
          placeholder="Search signals..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full"
        />
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {signals.length > 0 ? (
            signals.map((signal) => <SignalCard key={signal.id} signal={signal} />)
          ) : (
            <p className="text-center text-gray-500 dark:text-gray-400 py-8">No recent signals or changes matching your search.</p>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default SignalsFeed;