"use client";

import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import AccountFocusCard from "./AccountFocusCard";
import { Account } from "@/types/daily-focus";
import { Input } from "@/components/ui/input"; // Import Input component

interface FocusQueueProps {
  accounts: Account[];
  selectedAccountId: string | null;
  onSelectAccount: (accountId: string) => void;
  searchTerm: string; // New prop for search term
  onSearchChange: (term: string) => void; // New prop for search handler
}

const FocusQueue: React.FC<FocusQueueProps> = ({ accounts, selectedAccountId, onSelectAccount, searchTerm, onSearchChange }) => {
  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-950 border-r border-gray-200 dark:border-gray-800">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold mb-3">Today's Focus Queue</h2>
        <Input
          placeholder="Search accounts..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full"
        />
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {accounts.length > 0 ? (
            accounts.map((account) => (
              <AccountFocusCard
                key={account.id}
                account={account}
                isSelected={account.id === selectedAccountId}
                onSelect={onSelectAccount}
              />
            ))
          ) : (
            <p className="text-center text-gray-500 dark:text-gray-400 py-8">No accounts found matching your search.</p>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default FocusQueue;