"use client";

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button"; // Import Button component
import { Gift, HelpCircle, Bell, Search } from "lucide-react";

const HeaderBar = () => {
  const location = useLocation();

  const navItems = [
    { name: "Home", path: "/home" }, // Assuming a home page might be added later
    { name: "Accounts", path: "/" }, // Root is Accounts
    { name: "Leads", path: "/leads" }, // Placeholder for Leads
    { name: "Messaging", path: "/messaging" }, // Placeholder for Messaging
  ];

  return (
    <header className="bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800 py-2 px-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        {/* LinkedIn Sales Navigator Logo */}
        <div className="flex items-center space-x-1">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/LinkedIn_logo_initials.png/600px-LinkedIn_logo_initials.png" alt="LinkedIn Logo" className="h-6 w-6" />
          <span className="text-lg font-semibold text-gray-800 dark:text-gray-100">SALES NAVIGATOR</span>
        </div>

        {/* Main Navigation */}
        <nav className="hidden md:flex space-x-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={cn(
                "px-3 py-2 text-sm font-medium text-gray-600 dark:text-gray-400",
                "hover:text-blue-700 hover:bg-gray-100 dark:hover:bg-gray-800 dark:hover:text-blue-400",
                "rounded-md transition-colors duration-200",
                location.pathname === item.path && "text-blue-700 dark:text-blue-400 bg-gray-100 dark:bg-gray-800"
              )}
            >
              {item.name}
            </Link>
          ))}
        </nav>
      </div>

      {/* Right-side icons and search */}
      <div className="flex items-center space-x-4">
        <div className="relative hidden lg:block">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            type="text"
            placeholder="Search keywords"
            className="pl-8 pr-2 py-1 text-sm rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:ring-blue-500 focus:border-blue-500 w-48"
          />
        </div>
        <Button variant="ghost" size="icon" className="text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800">
          <Gift className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800">
          <HelpCircle className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800">
          <Bell className="h-5 w-5" />
        </Button>
        <Avatar className="h-8 w-8 cursor-pointer">
          <AvatarImage src="https://via.placeholder.com/40/0000FF/FFFFFF?text=U" alt="User Avatar" />
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
};

export default HeaderBar;