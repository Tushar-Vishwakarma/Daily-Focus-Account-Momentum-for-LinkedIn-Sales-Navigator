export type Account = {
  id: string;
  name: string;
  logoUrl: string;
  size: string; // e.g., "100-500 employees"
  industry: string;
  momentum: number; // percentage change
  momentumDirection: 'up' | 'down' | 'neutral';
  whatChanged: string;
  recommendedAction: 'Message' | 'Save lead' | 'View account';
  stakeholders: Stakeholder[];
  recentActivity: Activity[];
  riskOpportunitySignals: string[];
  isPeaking?: boolean; // New property for "Peaking" badge
};

export type Stakeholder = {
  id: string;
  name: string;
  title: string;
  avatarUrl: string;
};

export type Activity = {
  id: string;
  type: string; // e.g., "Post engagement", "Company page visit"
  description: string;
  timestamp: string; // ISO string
};

export type Signal = {
  id: string;
  type: string; // e.g., "Job Change", "Engagement Spike", "Hiring Trend"
  description: string;
  accountName?: string; // Optional, if signal is account-specific
  leadName?: string; // Optional, if signal is lead-specific
  timestamp: string; // ISO string;
};