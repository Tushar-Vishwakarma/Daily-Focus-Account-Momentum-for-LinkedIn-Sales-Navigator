"use client";

import React from "react";
import FocusQueue from "@/components/FocusQueue";
import SignalsFeed from "@/components/SignalsFeed";
import AccountDetailPreview from "@/components/AccountDetailPreview"; // Import AccountDetailPreview
import { mockAccounts, mockSignals } from "@/data/mock-data";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

const DailyFocusPage = () => {
  const [selectedAccountId, setSelectedAccountId] = React.useState<string | null>(null); // Start with no account selected
  const [accountSearchTerm, setAccountSearchTerm] = React.useState<string>("");
  const [signalSearchTerm, setSignalSearchTerm] = React.useState<string>("");
  const [activeSubNav, setActiveSubNav] = React.useState<"lead" | "account">("account");

  const filteredAccounts = React.useMemo(() => {
    if (!accountSearchTerm) {
      return mockAccounts;
    }
    const lowerCaseSearchTerm = accountSearchTerm.toLowerCase();
    return mockAccounts.filter(
      (account) =>
        account.name.toLowerCase().includes(lowerCaseSearchTerm) ||
        account.industry.toLowerCase().includes(lowerCaseSearchTerm) ||
        account.whatChanged.toLowerCase().includes(lowerCaseSearchTerm)
    );
  }, [accountSearchTerm]);

  const filteredSignals = React.useMemo(() => {
    if (!signalSearchTerm) {
      return mockSignals;
    }
    const lowerCaseSearchTerm = signalSearchTerm.toLowerCase();
    return mockSignals.filter(
      (signal) =>
        signal.type.toLowerCase().includes(lowerCaseSearchTerm) ||
        signal.description.toLowerCase().includes(lowerCaseSearchTerm) ||
        (signal.accountName && signal.accountName.toLowerCase().includes(lowerCaseSearchTerm)) ||
        (signal.leadName && signal.leadName.toLowerCase().includes(lowerCaseSearchTerm))
    );
  }, [signalSearchTerm]);

  // Find the selected account based on selectedAccountId
  const selectedAccount = React.useMemo(
    () => filteredAccounts.find((acc) => acc.id === selectedAccountId),
    [selectedAccountId, filteredAccounts]
  );

  // If the selected account is filtered out, deselect it
  React.useEffect(() => {
    if (selectedAccountId && !selectedAccount) {
      setSelectedAccountId(null);
    }
  }, [filteredAccounts, selectedAccountId, selectedAccount]);


  return (
    <div className="flex h-[calc(100vh-60px)] bg-gray-50 dark:bg-gray-900">
      {/* Left Panel: Signals Feed (repurposed as filter/signals) */}
      <div className="flex-none w-[280px] border-r border-gray-200 dark:border-gray-800 overflow-y-auto">
        <SignalsFeed
          signals={filteredSignals}
          searchTerm={signalSearchTerm}
          onSearchChange={setSignalSearchTerm}
        />
      </div>

      {/* Main Content Area: Accounts List or Account Detail */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedAccount ? (
          <AccountDetailPreview account={selectedAccount} onBack={() => setSelectedAccountId(null)} />
        ) : (
          <>
            {/* Sub-navigation for Lead/Account */}
            <div className="flex items-center border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 px-4">
              <button
                onClick={() => setActiveSubNav("lead")}
                className={cn(
                  "py-3 px-4 text-sm font-medium border-b-2 transition-colors duration-200",
                  activeSubNav === "lead"
                    ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                    : "border-transparent text-gray-600 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400"
                )}
              >
                Lead
              </button>
              <button
                onClick={() => setActiveSubNav("account")}
                className={cn(
                  "py-3 px-4 text-sm font-medium border-b-2 transition-colors duration-200",
                  activeSubNav === "account"
                    ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                    : "border-transparent text-gray-600 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400"
                )}
              >
                Account
              </button>
            </div>

            {/* Search and Actions Bar */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Search keywords"
                    value={accountSearchTerm}
                    onChange={(e) => setAccountSearchTerm(e.target.value)}
                    className="w-64 pl-8"
                  />
                </div>
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {filteredAccounts.length} results
                </span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="select-all" />
                  <label htmlFor="select-all" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Select all
                  </label>
                </div>
                <Button variant="ghost" className="text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900">
                  Save to list
                </Button>
                <Button variant="ghost" className="text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900">
                  Unsave
                </Button>
              </div>
            </div>

            {/* Accounts List */}
            <div className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900">
              <FocusQueue
                accounts={filteredAccounts}
                selectedAccountId={selectedAccountId}
                onSelectAccount={setSelectedAccountId}
                searchTerm={""} // Search is now handled globally above
                onSearchChange={() => {}} // Search is now handled globally above
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default DailyFocusPage;