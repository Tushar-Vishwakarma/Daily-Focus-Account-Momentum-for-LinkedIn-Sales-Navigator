import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import DailyFocusPage from "./pages/DailyFocusPage";
import HeaderBar from "./components/HeaderBar"; // Import the new HeaderBar

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <HeaderBar /> {/* Include the HeaderBar here */}
        <Routes>
          <Route path="/" element={<DailyFocusPage />} /> {/* Make DailyFocusPage the default */}
          <Route path="/home" element={<Index />} /> {/* Keep Index as a separate home page */}
          <Route path="/daily-focus" element={<DailyFocusPage />} />
          {/* Placeholder routes for Leads and Messaging */}
          <Route path="/leads" element={<div className="p-4 text-center text-gray-600 dark:text-gray-400">Leads Page (Coming Soon!)</div>} />
          <Route path="/messaging" element={<div className="p-4 text-center text-gray-600 dark:text-gray-400">Messaging Page (Coming Soon!)</div>} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;